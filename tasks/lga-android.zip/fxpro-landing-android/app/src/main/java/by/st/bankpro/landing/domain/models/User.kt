package by.st.bankpro.landing.domain.models

data class User (
    val firstName: String,
    val lastName: String,
    val email: String
)