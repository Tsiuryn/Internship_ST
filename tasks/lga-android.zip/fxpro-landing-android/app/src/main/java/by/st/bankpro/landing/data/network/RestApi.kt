package by.st.bankpro.landing.data.network

interface RestApi {

}