package by.st.bankpro.landing.ui.screens

import androidx.lifecycle.ViewModel

class StartViewModel : ViewModel() {

}