package by.st.bankpro.landing.data.network.models.converters

import by.st.bankpro.landing.data.network.models.UserJson
import by.st.bankpro.landing.domain.models.User

fun createUserJson(user: User): UserJson {
    TODO()
}

fun createUser(userJson: UserJson): User {
    TODO()
}