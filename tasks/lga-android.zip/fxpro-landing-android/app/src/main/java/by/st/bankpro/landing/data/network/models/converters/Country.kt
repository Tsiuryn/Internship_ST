package by.st.bankpro.landing.data.network.models.converters

import by.st.bankpro.landing.data.network.models.CountryJson
import by.st.bankpro.landing.domain.models.Country

fun createCountry(json: CountryJson): Country {
    TODO()
}