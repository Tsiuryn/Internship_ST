package by.st.bankpro.landing

val API_URL = ""