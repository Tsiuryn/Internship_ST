package by.st.bankpro.landing.ui.screens.main

import androidx.lifecycle.ViewModel
import by.st.bankpro.landing.domain.usecase.GetCountries

class MainViewModel(

) : ViewModel() {

}