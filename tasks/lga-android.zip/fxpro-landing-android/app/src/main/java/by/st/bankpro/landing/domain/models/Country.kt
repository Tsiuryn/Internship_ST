package by.st.bankpro.landing.domain.models

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Country(
    val i: String
): Parcelable